package proyectoS1;

import java.util.ArrayList;

/**
 * @author Admin
 *
 */
public class Reproductor {

	
	public static void main(String[] args) {
		generarVideo();
	}
	
	public static void generarVideo() {
		ArrayList<Video> videos = new ArrayList<>();
		
		Video podcast = new Podcast("Podcast", "Autor", 22.3, "Charla");
		Video entrevista = new Entrevista("Video", "OtroAutor", 55.2, "Entrevistado");
		Video musical = new Musical("videoMusical", "Cantante", 3.2);
		Video cancion = new Cancion("Canción", "Cantante", 3.2, "Colaborador");
		
		videos.add(entrevista);
		videos.add(cancion);
		videos.add(musical);
		videos.add(podcast);
		
		for (Video v : videos) {
			if (v instanceof Cancion) {
				((Cancion) v).escuchar();
				v.toString();
			} else {
				v.ver();
				v.escuchar();
			}
		}
		
	}

}
