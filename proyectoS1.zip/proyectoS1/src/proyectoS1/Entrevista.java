package proyectoS1;

/**
 * @author Admin
 *
 */
public class Entrevista implements Video {
	
	private String nombre;
	private String autor;
	private double duracion;
	private final String entrevistado;

	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 * @param entrevistado
	 */
	public Entrevista(String nombre, String autor, double duracion, String entrevistado) {
		super();
		this.nombre = nombre;
		this.autor = autor;
		this.duracion = duracion;
		this.entrevistado = entrevistado;
	}

	/**
	 *Override method
	 */
	@Override
	public void ver() {
		System.out.println("Viendo la entrevista "+nombre+" con duración "+duracion);
	}
	
	/**
	 *Override method
	 */
	@Override
	public void escuchar() {
		System.out.println("Escuchando la entrevista "+nombre+" a "+entrevistado);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public double getDuracion() {
		return duracion;
	}

	public void setDuracion(double duracion) {
		this.duracion = duracion;
	}

	public String getEntrevistado() {
		return entrevistado;
	}

	@Override
	public String toString() {
		return "Entrevista [entrevistado=" + entrevistado + "]";
	}

}
