package proyectoS1;

/**
 * @author Admin
 *
 */
public class Cancion extends Musical {
	
	private String colaborador;
	
	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 */
	public Cancion(String nombre, String autor, double duracion) {
		super(nombre, autor, duracion);
		
	}
	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 * @param colaborador
	 */
	public Cancion(String nombre, String autor, double duracion, String colaborador) {
		super(nombre, autor, duracion, colaborador);
	}
	
	public String getColaborador() {
		return colaborador;
	}
	
	/**
	 *Override method
	 */
	@Override
	public void escuchar() {
		System.out.println("Escuchando la canción "+getNombre());
	}

	public void setColaborador(String colaborador) {
		this.colaborador = colaborador;
	}

	@Override
	public String toString() {
		return "Canción [colaborador=" + colaborador + "]";
	}
}
