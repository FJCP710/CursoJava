package proyectoS1;

/**
 * @author Admin
 *
 */
public interface Video {
	public static String nombre = "";
	public static String autor = "";
	public static final double duracion = 0;
	
	public void ver();
	
	public void escuchar();
	
}
