package proyectoS1;

/**
 * @author Admin
 *
 */
public class Podcast implements Video{
	
	private String nombre;
	private String autor;
	private double duracion;
	private String contenido;
	
	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 * @param contenido
	 */
	public Podcast(String nombre, String autor, double duracion, String contenido) {
		super();
		this.nombre = nombre;
		this.autor = autor;
		this.duracion = duracion;
		this.contenido = contenido;
	}
	
	/**
	 *Override method
	 */
	@Override
	public void ver() {
		System.out.println("Viendo el podcast "+nombre+" con duración "+duracion);
	}
	
	/**
	 *Override method
	 */
	@Override
	public void escuchar() {
		System.out.println("Escuchando el podcast "+nombre+" de contenido "+contenido);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public double getDuracion() {
		return duracion;
	}

	public void setDuracion(double duracion) {
		this.duracion = duracion;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	@Override
	public String toString() {
		return "Podcast [contenido=" + contenido + "]";
	}
	
}
