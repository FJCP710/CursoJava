package proyectoS1;

/**
 * @author Admin
 *
 */
public class Musical implements Video {

	protected String nombre;
	protected String autor;
	protected double duracion;
	protected String colaborador;
	
	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 * @param colaborador
	 */
	public Musical(String nombre, String autor, double duracion, String colaborador) {
		super();
		this.nombre = nombre;
		this.autor = autor;
		this.duracion = duracion;
		this.colaborador = colaborador;
	}

	/**
	 * @param nombre
	 * @param autor
	 * @param duracion
	 */
	public Musical(String nombre, String autor, double duracion) {
		super();
		this.nombre = nombre;
		this.autor = autor;
		this.duracion = duracion;
	}

	public String getColaborador() {
		return colaborador;
	}

	/**
	 *Override method
	 */
	@Override
	public void ver() {
		System.out.println("Viendo el vídeo musical "+nombre+" con duración "+duracion);
	}
	
	/**
	 *Override method
	 */
	@Override
	public void escuchar() {
		System.out.println("Escuchando el vídeo musical "+nombre);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public double getDuracion() {
		return duracion;
	}

	public void setDuracion(double duracion) {
		this.duracion = duracion;
	}

	public void setColaborador(String colaborador) {
		this.colaborador = colaborador;
	}

	@Override
	public String toString() {
		return "Musical [colaborador=" + colaborador + "]";
	}
}
